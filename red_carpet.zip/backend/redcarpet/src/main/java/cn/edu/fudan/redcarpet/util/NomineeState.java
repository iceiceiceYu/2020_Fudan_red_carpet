package cn.edu.fudan.redcarpet.util;

public enum NomineeState {
    REJECTED,
    PENDING,
    PASSED
}
