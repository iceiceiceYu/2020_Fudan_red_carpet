# Red Carpet
Back end for the red carpet party in Fudan University

## 文件目录
- backend: 后端代码。
- docs: 文档。
- frontend: 后台前端源码。后台的前端，用于给操作人员管理整个投票系统。
